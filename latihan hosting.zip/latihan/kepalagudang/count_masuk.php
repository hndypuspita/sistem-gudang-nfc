<?php
require_once 'config.php';

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Query untuk menghitung kartu masuk
$sql_masuk = "SELECT COUNT(*) as count_masuk FROM masuk";
$result_masuk = $conn->query($sql_masuk);
$count_masuk = 0;
if ($result_masuk->num_rows > 0) {
    $row = $result_masuk->fetch_assoc();
    $count_masuk = $row['count_masuk'];
}

// Query untuk menghitung kartu keluar
$sql_keluar = "SELECT COUNT(*) as count_keluar FROM keluar";
$result_keluar = $conn->query($sql_keluar);
$count_keluar = 0;
if ($result_keluar->num_rows > 0) {
    $row = $result_keluar->fetch_assoc();
    $count_keluar = $row['count_keluar'];
}

$conn->close();

echo json_encode(['count_masuk' => $count_masuk, 'count_keluar' => $count_keluar]);
?>

