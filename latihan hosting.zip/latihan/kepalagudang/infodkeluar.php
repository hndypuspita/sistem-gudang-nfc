<!DOCTYPE html>
<html lang="en">
<head>
<!-- Required meta tags -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css">
<link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js'>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/boxicons@latest/css/boxicons.min.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<link rel="stylesheet" href="reminderkep.css">
</head>

<body id="body-pd">
    <header class="header" id="header">
        <div class="header_toggle"> <i class='bx bx-menu' id="header-toggle"></i> </div>
        <div class="header_img"> <img src="https://th.bing.com/th/id/OIP.mHT5_JTZ1lKwFRDFsDWlVwAAAA?rs=1&pid=ImgDetMain" alt=""> </div>
    </header>
    <div class="l-navbar" id="nav-bar">
        <nav class="nav">
            <div> <a href="#" class="nav_logo">  
             <i class='bx bx-layer nav_logo-icon'></i> 
                <span class="nav_logo-name">PT.Globalindo</span> </a>
                <div class="nav_list"> <a href="dashboard.php" class="nav_link active"><i class='bx bx-grid-alt nav_icon'></i> 
                <span class="nav_name">Dashboard</span> </a> 

                <a href="kartumasuk.php" class="nav_link"><i class='bx bx-user nav_icon'></i> 
                <span class="nav_name">Kartu Masuk</span> </a> 

                <a href="kartukeluar.php" class="nav_link"><i class='bx bx-message-square-detail nav_icon'></i> 
                <span class="nav_name">Kartu Keluar</span> </a> 

                <a href="reminderkepala.php" class="nav_link"><i class='bx bx-home nav_icon'></i> 
                <span class="nav_name">Barang 6 bulan </span> </a> 

                <a href="inforak.php" class="nav_link"><i class='bx bx-home nav_icon'></i> 
                <span class="nav_name">Informasi Rak</span> </a>

            </div> 
            <a href="login.php" class="nav_link"> <i class='bx bx-log-out nav_icon'></i> 
            <span class="nav_name">Keluar</span> </a>
        </nav>
    </div>
    
<div class="content">
<br>
<h2> Detail Keluar</h2>
    <div class="row">
        <div class="col">
        <button type="button" class="btn btn-primary" onclick="window.history.back();">Kembali</button>
        </div>
    </div>
    </div>
</div>
    <br>
<?php
// Ambil nomor struk dari parameter GET
$kode_keluar = $_GET['id']; // Ubah 'No_Struk' menjadi 'id'

// Ambil data detail penjualan dari database berdasarkan nomor struk
require_once 'config.php';

// Query untuk mengambil data detail masuk berdasarkan kode masuk
$query = "SELECT dk.*, b.nama_buyer, r.nama_rak, s.nama_slot
FROM detail_keluar dk
INNER JOIN buyer b ON dk.kode_buyer = b.kode_buyer
INNER JOIN rak r ON dk.kode_rak = r.kode_rak
INNER JOIN slot s ON dk.kode_slot = s.kode_slot
WHERE dk.kode_keluar = '$kode_keluar'";

$result = $conn->query($query);

if ($result->num_rows > 0) {
    echo "<table border='1'>";
    echo "<tr>
    <th>Kode Keluar</th>
    <th>Nama Buyer</th>
    <th>Nama Rak</th>
    <th>Nama Slot</th>
    <th>No Roll</th>
    <th>QTY Keluar</th>
        </tr>";

        while ($row = $result->fetch_assoc()) {
            $kode_keluar = $row["kode_keluar"];
            $nama_buyer = $row["nama_buyer"];
            $nama_rak = $row["nama_rak"];
            $nama_slot = $row["nama_slot"];
            $no_roll = $row["no_roll"];
            $qty_keluar = $row["qty_keluar"];
    
            echo "<tr>";
            echo "<td>$kode_keluar</td>";
            echo "<td>$nama_buyer</td>";
            echo "<td>$nama_rak</td>";
            echo "<td>$nama_slot</td>";
            echo "<td>$no_roll</td>";
            echo "<td>$qty_keluar</td>";
            echo "</tr>";
        }

    echo "</table>";
} else {
    echo "Tidak ada detail penjualan untuk nomor struk tersebut.";
}

$conn->close();
?>

</div>
<script>
        document.addEventListener("DOMContentLoaded", function(event) {
   
   const showNavbar = (toggleId, navId, bodyId, headerId) =>{
   const toggle = document.getElementById(toggleId),
   nav = document.getElementById(navId),
   bodypd = document.getElementById(bodyId),
   headerpd = document.getElementById(headerId)
   
   // Validate that all variables exist
   if(toggle && nav && bodypd && headerpd){
   toggle.addEventListener('click', ()=>{
   // show navbar
   nav.classList.toggle('show')
   // change icon
   toggle.classList.toggle('bx-x')
   // add padding to body
   bodypd.classList.toggle('body-pd')
   // add padding to header
   headerpd.classList.toggle('body-pd')
   })
   }
   }
   
   showNavbar('header-toggle','nav-bar','body-pd','header')
   
   /*===== LINK ACTIVE =====*/
   const linkColor = document.querySelectorAll('.nav_link')
   
   function colorLink(){
   if(linkColor){
   linkColor.forEach(l=> l.classList.remove('active'))
   this.classList.add('active')
   }
   }
   linkColor.forEach(l=> l.addEventListener('click', colorLink))
   
    // Your code to run since DOM is loaded and ready
   });
   </script>
</body>
</html>