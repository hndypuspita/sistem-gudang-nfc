<?php
$mysqli = new mysqli('153.92.15.8', 'u110873812_team', 'taffgoMP004', 'u110873812_db_warehouse');

if ($mysqli->connect_error) {
    die('Connect Error (' . $mysqli->connect_errno . ') ' . $mysqli->connect_error);
}
?>