<?php
session_start();
$username = isset($_SESSION['username']) ? $_SESSION['username'] : 'Guest'; // Default ke 'Guest' jika tidak ada username di session
?>
<html>
    <head>
        <!-- Required meta tags -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css">
<link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js'>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/boxicons@latest/css/boxicons.min.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<link rel="stylesheet" href="dashkepala.css">   
</head>
<body id="body-pd">
    <header class="header" id="header">
        <div class="header_toggle"> <i class='bx bx-menu' id="header-toggle"></i> </div>
        <div class="header_img"> <img src="https://th.bing.com/th/id/OIP.mHT5_JTZ1lKwFRDFsDWlVwAAAA?rs=1&pid=ImgDetMain" alt=""> </div>
  </header>
  <div class="progress">
  <div class="progress-bar bg-success" role="progressbar" style="width: 11%" aria-valuenow="11" aria-valuemin="0" aria-valuemax="100"></div>
  <div class="progress-bar bg-success" role="progressbar" style="width: 11%" aria-valuenow="11" aria-valuemin="0" aria-valuemax="100"></div>
  <div class="progress-bar bg-success" role="progressbar" style="width: 11%" aria-valuenow="11" aria-valuemin="0" aria-valuemax="100"></div>
</div>
    <div class="l-navbar" id="nav-bar">
        <nav class="nav">
            <div> <a href="#" class="nav_logo"> 
                <i class='bx bx-layer nav_logo-icon'></i> 
                <span class="nav_logo-name">PT.Globalindo</span> </a>
                <div class="nav_list"> <a href="dashboard.php" class="nav_link active"><i class='bx bx-grid-alt nav_icon'></i> 
                <span class="nav_name">Dashboard</span> </a> 

                <a href="kartumasuk.php" class="nav_link"><i class='bx bx-user nav_icon'></i> 
                <span class="nav_name">Kartu Masuk</span> </a> 

                <a href="kartukeluar.php" class="nav_link"><i class='bx bx-message-square-detail nav_icon'></i> 
                <span class="nav_name">Kartu Keluar</span> </a> 

                <a href="reminderkepala.php" class="nav_link"><i class='bx bx-home nav_icon'></i> 
                <span class="nav_name">Barang 6 bulan </span> </a> 

                <a href="inforak.php" class="nav_link"><i class='bx bx-home nav_icon'></i> 
                <span class="nav_name">Informasi Rak</span> </a>

            </div> 
            <a href="../login.php" class="nav_link"> <i class='bx bx-log-out nav_icon'></i> 
            <span class="nav_name">Keluar</span> </a>
        </nav>
    </div>

    <!--Container Main start-->
    <div class="height-100 bg-light">
    <?php 
    //require_once 'menu.php'; 
    ?> 
    <!-- content menu -->
    <table>
    <!-- <tr>
<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet">
<div class="container-hello">
    <div class="row">
        <div class="col-md-4 col-xl-3">
            <div class="card-hello bg-c-blue order-card">
                <div class="card-block">
                <h6 class="satu">Hallo <b><?php echo htmlspecialchars($username); ?></b></h6>
                    <p class="dua">selamat mengerjakan tugasmu digudang</p>
                </div>
            </div>
        </div>
    </tr> -->
            <tr>
        <div class="container"> 
           <div class="d-lg-flex"> <div class="card border-0 me-lg-4 mb-lg-0 mb-4"> 
            <div class="backgroundEffect"></div>
            <div class="content"> <p class="h-1 mt-4">RAK 1</p>
            <div class="d-flex align-items-center justify-content-between mt-3 pb-3"> 
            <a href="detailrak1.php"><div class="btn btn-primary">Masuk<span class="fas fa-arrow-right"></span></div></a> 
            </div> </div> </div>
                         
            <div class="d-lg-flex"> <div class="card border-0 me-lg-4 mb-lg-0 mb-4"> 
                <div class="backgroundEffect"></div><div class="content"> <p class="h-1 mt-4">RAK 2</p>
                      <div class="d-flex align-items-center justify-content-between mt-3 pb-3"> 
                      <a href="detailrak2.php"><div class="btn btn-primary">Masuk<span class="fas fa-arrow-right"></span></div></a>
                         </div> </div> </div>
               
            <div class="d-lg-flex"> <div class="card border-0 me-lg-4 mb-lg-0 mb-4"> 
                <div class="backgroundEffect"></div><div class="content"> <p class="h-1 mt-4">RAK 3</p>
                      <div class="d-flex align-items-center justify-content-between mt-3 pb-3"> 
                      <a href="detailrak3.php"><div class="btn btn-primary">Masuk<span class="fas fa-arrow-right"></span></div></a> 
                         </div> </div> </div></tr>
            <tr>
            <div class="container"> 
            <div class="d-lg-flex"> <div class="card border-0 me-lg-4 mb-lg-0 mb-4"> 
                <div class="backgroundEffect"></div><div class="content"> <p class="h-1 mt-4">RAK 4</p>
                      <div class="d-flex align-items-center justify-content-between mt-3 pb-3"> 
                      <a href="detailrak4.php"><div class="btn btn-primary">Masuk<span class="fas fa-arrow-right"></span></div></a> 
                         </div> </div> </div>
                    
            <div class="d-lg-flex"> <div class="card border-0 me-lg-4 mb-lg-0 mb-4"> 
                <div class="backgroundEffect"></div><div class="content"> <p class="h-1 mt-4">RAK 5</p>
                      <div class="d-flex align-items-center justify-content-between mt-3 pb-3"> 
                      <a href="detailrak5.php"><div class="btn btn-primary">Masuk<span class="fas fa-arrow-right"></span></div></a>
                         </div> </div> </div>
        
            <div class="d-lg-flex"> <div class="card border-0 me-lg-4 mb-lg-0 mb-4"> 
                <div class="backgroundEffect"></div><div class="content"> <p class="h-1 mt-4">RAK 6</p>
                      <div class="d-flex align-items-center justify-content-between mt-3 pb-3"> 
                      <a href="detailrak6.php"><div class="btn btn-primary">Masuk<span class="fas fa-arrow-right"></span></div></a>
                         </div> </div> </div>
</div>        
</tr>
</table>
<!-- end content menu -->
     <script>
        document.addEventListener("DOMContentLoaded", function(event) {
   
   const showNavbar = (toggleId, navId, bodyId, headerId) =>{
   const toggle = document.getElementById(toggleId),
   nav = document.getElementById(navId),
   bodypd = document.getElementById(bodyId),
   headerpd = document.getElementById(headerId)
   
   // Validate that all variables exist
   if(toggle && nav && bodypd && headerpd){
   toggle.addEventListener('click', ()=>{
   // show navbar
   nav.classList.toggle('show')
   // change icon
   toggle.classList.toggle('bx-x')
   // add padding to body
   bodypd.classList.toggle('body-pd')
   // add padding to header
   headerpd.classList.toggle('body-pd')
   })
   }
   }
   
   showNavbar('header-toggle','nav-bar','body-pd','header')
   
   /*===== LINK ACTIVE =====*/
   const linkColor = document.querySelectorAll('.nav_link')
   
   function colorLink(){
   if(linkColor){
   linkColor.forEach(l=> l.classList.remove('active'))
   this.classList.add('active')
   }
   }
   linkColor.forEach(l=> l.addEventListener('click', colorLink))
   
    // Your code to run since DOM is loaded and ready
   });
   </script>
</body>
</html>