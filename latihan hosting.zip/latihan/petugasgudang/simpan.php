<?php
require_once 'config.php';

$details = json_decode(file_get_contents('php://input'), true);
$response = ['success' => false];

if (!empty($details)) {
    foreach ($details as $detail) {
        $kode_masuk = $detail['kode_masuk'];
        $nama_rak = $detail['nama_rak'];
        $nama_slot = $detail['nama_slot'];
        $no_roll = $detail['no_roll'];
        $qty_masuk = $detail['qty_masuk'];

        $sql = "INSERT INTO detail_masuk (kode_masuk, kode_rak, kode_slot, no_roll, qty_masuk) VALUES ('$kode_masuk', '$nama_rak', '$nama_slot', '$no_roll', '$qty_masuk')";
        if ($conn->query($sql) === TRUE) {
            $response['success'] = true;
        } else {
            $response['success'] = false;
            break;
        }
    }
}

echo json_encode($response);
$conn->close();
?>