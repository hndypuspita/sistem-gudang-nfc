<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Kartu Masuk</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Boxicons CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/boxicons@latest/css/boxicons.min.css">
    <!-- Your custom CSS -->
    <link rel="stylesheet" href="reminderkep.css">
    <style>
        .content {
            padding: 20px;
        }
        .btn-container {
            position: fixed;
            top: 20%;
            right: 20px;
        }
        .table-container {
            margin-top: 20px;
        }
        .baris{
            background-color: blue;
        }
        
        
    </style>
</head>
<body id="body-pd">
    <header class="header" id="header">
        <div class="header_toggle"> <i class='bx bx-menu' id="header-toggle"></i> </div>
        <div class="header_img"> <img src="https://th.bing.com/th/id/OIP.mHT5_JTZ1lKwFRDFsDWlVwAAAA?rs=1&pid=ImgDetMain" alt=""> </div>
    </header>
    <div class="l-navbar" id="nav-bar">
        <nav class="nav">
            <div> 
                <a href="#" class="nav_logo"> 
                <i class='bx bx-layer nav_logo-icon'></i> 
                <span class="nav_logo-name">PT.Globalindo</span> </a>
                <div class="nav_list"> <a href="dashboard.php" class="nav_link active"><i class='bx bx-grid-alt nav_icon'></i> 
                <span class="nav_name">Dashboard</span> </a> 

                <a href="kartumasuk.php" class="nav_link"><i class='bx bx-user nav_icon'></i> 
                <span class="nav_name">Kartu Masuk</span> </a> 

                <a href="kartukeluar.php" class="nav_link"><i class='bx bx-message-square-detail nav_icon'></i> 
                <span class="nav_name">Kartu Keluar</span> </a> 

                <a href="reminderkepala.php" class="nav_link"><i class='bx bx-home nav_icon'></i> 
                <span class="nav_name">Barang 6 bulan </span> </a> 

                <a href="inforak.php" class="nav_link"><i class='bx bx-home nav_icon'></i> 
                <span class="nav_name">Informasi Rak</span> </a>

            </div> 
            <a href="../login.php" class="nav_link"> <i class='bx bx-log-out nav_icon'></i> 
            <span class="nav_name">Keluar</span> </a>
        </nav>
    </div>
    <div class="content">
        <div class="container">
            <div class="row">
                <h2> Detail Kartu Masuk </h2>
                <div class="col">
                <button type="button" class="btn btn-primary" onclick="window.history.back();">Kembali</button>
    </div>
            <div class="table-container">
                <?php
                require_once 'config.php';

                $kode_masuk = $_GET['id'];

                // Query untuk mengambil data detail masuk berdasarkan kode masuk
                $query = "SELECT dm.*, r.nama_rak, s.nama_slot
                          FROM detail_masuk dm
                          INNER JOIN rak r ON dm.kode_rak = r.kode_rak
                          INNER JOIN slot s ON dm.kode_slot = s.kode_slot
                          WHERE dm.kode_masuk = '$kode_masuk'";

                $result = $conn->query($query);

                if ($result->num_rows > 0) {
                    echo "<table class='table table-bordered table-primary'>";
                    echo "<table class='table table-bordered'>";
                    echo "<thead>
                            <tr class='baris table-primary'>
                                <th scope='col'>Kode Masuk</th>
                                <th scope='col'>No Roll</th>
                                <th scope='col'>Qty Masuk</th>
                                <th scope='col'>Nama Rak</th>
                                <th scope='col'>Nama Slot</th>
                            </tr>
                          </thead>";
                    echo "<tbody>";

                    while ($row = $result->fetch_assoc()) {
                        $kode_masuk = $row["kode_masuk"];
                        $no_roll = $row["no_roll"];
                        $qty_masuk = $row["qty_masuk"];
                        $nama_rak = $row["nama_rak"];
                        $nama_slot = $row["nama_slot"];

                        echo "<tr>";
                        echo "<td>$kode_masuk</td>";
                        echo "<td>$no_roll</td>";
                        echo "<td>$qty_masuk</td>";
                        echo "<td>$nama_rak</td>";
                        echo "<td>$nama_slot</td>";
                        echo "</tr>";
                    }

                    echo "</tbody>";
                    echo "</table>";
                } else {
                    echo "Tidak ada detail penjualan untuk nomor struk tersebut.";
                }

                $conn->close();
                ?>
            </div>
        </div>
    </div>
    <!-- Bootstrap JS and Custom Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // JavaScript for toggling sidebar and active links
        document.addEventListener("DOMContentLoaded", function(event) {
            const showNavbar = (toggleId, navId, bodyId, headerId) => {
                const toggle = document.getElementById(toggleId),
                    nav = document.getElementById(navId),
                    bodypd = document.getElementById(bodyId),
                    headerpd = document.getElementById(headerId);

                if (toggle && nav && bodypd && headerpd) {
                    toggle.addEventListener('click', () => {
                        nav.classList.toggle('show');
                        toggle.classList.toggle('bx-x');
                        bodypd.classList.toggle('body-pd');
                        headerpd.classList.toggle('body-pd');
                    });
                }
            };

            showNavbar('header-toggle', 'nav-bar', 'body-pd', 'header');

            // Toggle active link
            const linkColor = document.querySelectorAll('.nav_link');

            function colorLink() {
                if (linkColor) {
                    linkColor.forEach(l => l.classList.remove('active'));
                    this.classList.add('active');
                }
            }

            linkColor.forEach(l => l.addEventListener('click', colorLink));
        });
    </script>
</body>
</html>
