<?php

$servername = "153.92.15.8"; // Ganti dengan nama server database Anda
$username = "u110873812_team"; // Ganti dengan username database Anda
$password = "taffgoMP004"; // Ganti dengan password database Anda
$database = "u110873812_db_warehouse"; // Ganti dengan nama database Anda

// Membuat koneksi ke database
$conn = new mysqli($servername, $username, $password, $database);

// Memeriksa koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
    try {
        $pdo = new PDO("mysql:host=$servername;database=$database", $username, $password);
        // Set mode error untuk PDO agar melempar pengecualian jika terjadi kesalahan
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        echo "Koneksi berhasil";
    } catch(PDOException $e) {
        echo "Koneksi gagal: " . $e->getMessage();
    }}
?>

