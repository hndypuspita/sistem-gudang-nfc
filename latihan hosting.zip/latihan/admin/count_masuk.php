<?php
require_once 'config.php';

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

$sql = "SELECT COUNT(*) as count FROM user";
$result = $conn->query($sql);

$count = 0;
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $count = $row['count'];
}

$conn->close();

echo json_encode(['count' => $count]);
?>


