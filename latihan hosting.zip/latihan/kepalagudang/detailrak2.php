
<?php
include 'config.php';

$kode_rak = '1124';

// Query to fetch kartu masuk entries related to kode rak 1124 from detail_masuk
$sqlKartuMasuk = "
    SELECT DISTINCT km.kode_masuk, km.tgl_masuk, km.no_invoice, km.no_po,
                    b.nama_buyer, c.nama_color, a.nama_artikel, s.nama_supplier
    FROM masuk km
    JOIN detail_masuk dm ON km.kode_masuk = dm.kode_masuk
    JOIN buyer b ON km.kode_buyer = b.kode_buyer
    JOIN color c ON km.kode_color = c.kode_color
    JOIN artikel a ON km.kode_artikel = a.kode_artikel
    JOIN supplier s ON km.kode_supplier = s.kode_supplier
    WHERE dm.kode_rak = '$kode_rak'
";

// Query to fetch kartu keluar entries related to kode rak 1124 from detail_keluar
$sqlKartuKeluar = "
    SELECT DISTINCT kk.kode_keluar, kk.unit, kk.tgl_keluar, kk.alokasi_orc, kk.alokasi_style, kk.petugas,
                    b.nama_buyer, c.nama_color, a.nama_artikel, s.nama_supplier
    FROM keluar kk
    JOIN detail_keluar dk ON kk.kode_keluar = dk.kode_keluar
    JOIN buyer b ON kk.kode_buyer = b.kode_buyer
    JOIN color c ON kk.kode_color = c.kode_color
    JOIN artikel a ON kk.kode_artikel = a.kode_artikel
    JOIN supplier s ON kk.kode_supplier = s.kode_supplier
    WHERE dk.kode_rak = '$kode_rak'
";
// Execute queries
$resultKartuMasuk = $conn->query($sqlKartuMasuk);
$resultKartuKeluar = $conn->query($sqlKartuKeluar);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Detail Rak - <?php echo htmlspecialchars($kode_rak); ?></title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css">
    <link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/boxicons@latest/css/boxicons.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="dmasuk.css">
<body id="body-pd">
    <header class="header" id="header">
        <div class="header_toggle"> <i class='bx bx-menu' id="header-toggle"></i> </div>
        <div class="header_img"> <img src="https://th.bing.com/th/id/OIP.mHT5_JTZ1lKwFRDFsDWlVwAAAA?rs=1&pid=ImgDetMain" alt=""> </div>
    </header>
    <div class="l-navbar" id="nav-bar">
        <nav class="nav">
            <div> 
                <a href="#" class="nav_logo"> 
                <i class='bx bx-layer nav_logo-icon'></i> 
                <span class="nav_logo-name">PT.Globalindo</span> </a>
                <div class="nav_list"> <a href="dashboard.php" class="nav_link active"><i class='bx bx-grid-alt nav_icon'></i> 
                <span class="nav_name">Dashboard</span> </a> 

                <a href="kartumasuk.php" class="nav_link"><i class='bx bx-user nav_icon'></i> 
                <span class="nav_name">Kartu Masuk</span> </a> 

                <a href="kartukeluar.php" class="nav_link"><i class='bx bx-message-square-detail nav_icon'></i> 
                <span class="nav_name">Kartu Keluar</span> </a> 

                <a href="reminderkepala.php" class="nav_link"><i class='bx bx-home nav_icon'></i> 
                <span class="nav_name">Barang 6 bulan</span> </a> 

                <a href="inforak.php" class="nav_link"><i class='bx bx-home nav_icon'></i> 
                <span class="nav_name">Informasi Rak</span> </a>

            </div> 
            <a href="login.php" class="nav_link"> <i class='bx bx-log-out nav_icon'></i> 
            <span class="nav_name">Keluar</span> </a>
                </div>
            </div> 
            </a>
        </nav>
    </div>

    <!--Container Main start-->
    <div class="height-100 bg-light">
        <div class="content">
            <h2>Detail Rak: Rak A</h2>
            <h3>Daftar Kartu Masuk:</h3>
            <table>
                <thead>
                    <tr>
                        <th>No Kartu Masuk</th>
                        <th>Buyer</th>
                        <th>Artikel</th>
                        <th>Color</th>
                        <th>Tanggal Masuk</th>
                        <th>Supplier</th>
                        <th>No Invoice</th>
                        <th>No PO</th>
                        <th>Detail</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                <?php
            // Mengambil data produk dari database
            require_once 'config.php';
            $sql = "SELECT * FROM masuk 
                    INNER JOIN supplier on masuk.kode_supplier = supplier.kode_supplier
                    INNER JOIN buyer on masuk.kode_buyer = buyer.kode_buyer
                    INNER JOIN color on masuk.kode_color = color.kode_color
                    INNER JOIN artikrl on masuk.kode_artikel = artikel.kode_artikel
                    ";
                

                    ?>
                    <?php if ($resultKartuMasuk->num_rows > 0): ?>
                        <?php while ($row = $resultKartuMasuk->fetch_assoc()): ?>
                            <?php
                                $tgl_masuk = new DateTime($row['tgl_masuk']);
                                $tgl_sekarang = new DateTime();
                                $interval = $tgl_masuk->diff($tgl_sekarang);
                            ?>
                             <tr>
                                <td><?php echo htmlspecialchars($row['kode_masuk']); ?></td>
                                <td><?php echo htmlspecialchars($row['nama_buyer']); ?></td>
                                <td><?php echo htmlspecialchars($row['nama_artikel']); ?></td>
                                <td><?php echo htmlspecialchars($row['nama_color']); ?></td>
                                <td><?php echo htmlspecialchars($row['tgl_masuk']); ?></td>
                                <td><?php echo htmlspecialchars($row['nama_supplier']); ?></td>
                                <td><?php echo htmlspecialchars($row['no_invoice']); ?></td>
                                <td><?php echo htmlspecialchars($row['no_po']); ?></td>
                                <td><a href="infodmasuk.php?id=<?php echo urlencode($row['kode_masuk']); ?>" class="btn btn-info btn-sm">Detail</a></td>
                                <td>
                                    <?php if ($interval->m >= 6): ?>
                                        <button class="btn btn-danger btn-sm">Outdated</button>
                                    <?php else: ?>
                                        <button class="btn btn-success btn-sm">Current</button>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="10">Data detail masih kosong, silakan isi detail.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
            <br><br>

             <!-- Display Kartu Keluar -->
        <h3>Daftar Kartu Keluar:</h3>
        <table>
            <thead>
                <tr>
                    <th>No Kartu Keluar</th>
                    <th>Buyer</th>
                    <th>Artikel</th>
                    <th>Color</th>
                    <th>Unit</th>
                    <th>Supplier</th>
                    <th>Tanggal Keluar</th>
                    <th>alokasi ORC</th>
                    <th>Alokasi Style</th>
                    <th>Petugas</th>
                    <th>Detail</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($resultKartuKeluar->num_rows > 0): ?>
                    <?php while ($row = $resultKartuKeluar->fetch_assoc()): ?>
                        <tr>
                                <td><?php echo htmlspecialchars($row['kode_keluar']); ?></td>
                                <td><?php echo htmlspecialchars($row['nama_buyer']); ?></td>
                                <td><?php echo htmlspecialchars($row['nama_artikel']); ?></td>
                                <td><?php echo htmlspecialchars($row['nama_color']); ?></td>
                                <td><?php echo htmlspecialchars($row['unit']); ?></td>
                                <td><?php echo htmlspecialchars($row['nama_supplier']); ?></td>
                                <td><?php echo htmlspecialchars($row['tgl_keluar']); ?></td>
                                <td><?php echo htmlspecialchars($row['alokasi_orc']); ?></td>
                                <td><?php echo htmlspecialchars($row['alokasi_style']); ?></td>
                                <td><?php echo htmlspecialchars($row['petugas']); ?></td>
                                <td><a href="infodkeluar.php?id=<?php echo urlencode($row['kode_keluar']); ?>" class="btn btn-info btn-sm">Detail</a></td>
                            </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="11">Data detail keluar masih kosong, silakan isi detail.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
            </table>
        </div>
    </div>
    <!--Container Main end-->
    <script>
        document.addEventListener("DOMContentLoaded", function(event) {
   
   const showNavbar = (toggleId, navId, bodyId, headerId) =>{
   const toggle = document.getElementById(toggleId),
   nav = document.getElementById(navId),
   bodypd = document.getElementById(bodyId),
   headerpd = document.getElementById(headerId)
   
   // Validate that all variables exist
   if(toggle && nav && bodypd && headerpd){
   toggle.addEventListener('click', ()=>{
   // show navbar
   nav.classList.toggle('show')
   // change icon
   toggle.classList.toggle('bx-x')
   // add padding to body
   bodypd.classList.toggle('body-pd')
   // add padding to header
   headerpd.classList.toggle('body-pd')
   })
   }
   }
   
   showNavbar('header-toggle','nav-bar','body-pd','header')
   
   /*===== LINK ACTIVE =====*/
   const linkColor = document.querySelectorAll('.nav_link')
   
   function colorLink(){
   if(linkColor){
   linkColor.forEach(l=> l.classList.remove('active'))
   this.classList.add('active')
   }
   }
   linkColor.forEach(l=> l.addEventListener('click', colorLink))
   
    // Your code to run since DOM is loaded and ready
   });
   </script>
</body>
</html>

<?php
$conn->close();
?>
