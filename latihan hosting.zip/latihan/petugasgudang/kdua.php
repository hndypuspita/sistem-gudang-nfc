<?php
session_start();
include 'config.php'; // File untuk koneksi database

// Inisialisasi variabel untuk pesan kesalahan atau sukses
$error = $success = '';

// Query untuk mendapatkan kode buyer terakhir dari tabel masuk
$query_last_buyer_code = "SELECT kode_buyer FROM masuk ORDER BY kode_buyer DESC LIMIT 1";
$result_last_buyer_code = mysqli_query($conn, $query_last_buyer_code);

if ($result_last_buyer_code && mysqli_num_rows($result_last_buyer_code) > 0) {
    $row_last_buyer_code = mysqli_fetch_assoc($result_last_buyer_code);
    $last_buyer_code = $row_last_buyer_code['kode_buyer'];

    // Query untuk mendapatkan nama buyer berdasarkan kode buyer terakhir
    $query_last_buyer_name = "SELECT nama_buyer FROM buyer WHERE kode_buyer = '$last_buyer_code'";
    $result_last_buyer_name = mysqli_query($conn, $query_last_buyer_name);

    if ($result_last_buyer_name && mysqli_num_rows($result_last_buyer_name) > 0) {
        $row_last_buyer_name = mysqli_fetch_assoc($result_last_buyer_name);
        $last_buyer_name = $row_last_buyer_name['nama_buyer'];
    }

    // Gunakan kode buyer terakhir untuk mencari kode rak dari tabel buyer
    $query_nama_rak = "SELECT kode_rak FROM buyer WHERE kode_buyer = '$last_buyer_code'";
    $result_nama_rak = mysqli_query($conn, $query_nama_rak);

    if ($result_nama_rak && mysqli_num_rows($result_nama_rak) > 0) {
        $row_nama_rak = mysqli_fetch_assoc($result_nama_rak);
        $kode_rak = $row_nama_rak['kode_rak'];

        // Query untuk mendapatkan nama rak berdasarkan kode rak
        $query_last_rak_name = "SELECT nama_rak FROM rak WHERE kode_rak = '$kode_rak'";
        $result_last_rak_name = mysqli_query($conn, $query_last_rak_name);

        if ($result_last_rak_name && mysqli_num_rows($result_last_rak_name) > 0) {
            $row_last_rak_name = mysqli_fetch_assoc($result_last_rak_name);
            $last_rak_name = $row_last_rak_name['nama_rak'];
        }
    }
    // Query untuk mendapatkan qty masuk terakhir dari tabel roll
$query_last_qty_code = "SELECT qty_masuk FROM roll ORDER BY qty_masuk DESC LIMIT 1";
$result_last_qty_code = mysqli_query($conn, $query_last_qty_code);

if ($result_last_qty_code && mysqli_num_rows($result_last_qty_code) > 0) {
    $row_last_qty_code = mysqli_fetch_assoc($result_last_qty_code);
    $last_qty_code = $row_last_qty_code['qty_masuk'];
}
}

// Cek apakah tombol "Simpan" diklik
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["simpan"])) {
    // Cek apakah terdapat data detail masuk yang disimpan dalam session
    if (isset($_POST['kode_keluar']) && !empty($_POST['kode_keluar'])) {
        // Simpan data detail masuk ke dalam tabel detail_masuk
        $kode_keluar = $_POST['kode_keluar'];
        $nama_buyer = $_POST['nama_buyer'];
        $nama_rak = $_POST['nama_rak'];
        $nama_slot = $_POST['nama_slot'];
        $no_roll = $_POST['no_roll'];
        $qty_keluar = $_POST['qty_keluar'];

        // Query SQL untuk mendapatkan kode buyer berdasarkan nama buyer
        $query_buyer = "SELECT kode_buyer FROM buyer WHERE nama_buyer = '$nama_buyer'";
        $result_buyer = mysqli_query($conn, $query_buyer);
        $row_buyer = mysqli_fetch_assoc($result_buyer);
        $kode_buyer = $row_buyer['kode_buyer'];

        // Query SQL untuk mendapatkan kode rak berdasarkan nama rak
        $query_rak = "SELECT kode_rak FROM rak WHERE nama_rak = '$nama_rak'";
        $result_rak = mysqli_query($conn, $query_rak);
        $row_rak = mysqli_fetch_assoc($result_rak);
        $kode_rak = $row_rak['kode_rak'];

        // Query SQL untuk mendapatkan kode slot berdasarkan nama slot
        $query_slot = "SELECT kode_slot FROM slot WHERE nama_slot = '$nama_slot'";
        $result_slot = mysqli_query($conn, $query_slot);
        $row_slot = mysqli_fetch_assoc($result_slot);
        $kode_slot = $row_slot['kode_slot'];

    // Periksa apakah no_roll sudah ada di tabel roll
    $query_roll = "SELECT no_roll FROM roll WHERE no_roll = '$no_roll'";
    $result_roll = mysqli_query($conn, $query_roll);
    if (mysqli_num_rows($result_roll) == 0) {
        // Jika tidak ada, tambahkan no_roll ke tabel roll terlebih dahulu
        $query_insert_roll = "INSERT INTO roll (no_roll) VALUES ('$no_roll')";
        if (!mysqli_query($conn, $query_insert_roll)) {
            $error = "Error inserting roll: " . mysqli_error($conn);
        }
    }

        // Query SQL untuk menyimpan data detail masuk ke dalam tabel detail_masuk
        $sql = "INSERT INTO detail_keluar (kode_keluar, kode_buyer, kode_rak, kode_slot, no_roll, qty_keluar) 
                VALUES ('$kode_keluar', '$kode_buyer', '$kode_rak', '$kode_slot', '$no_roll', '$qty_keluar')";
            
        // Eksekusi query
        if (mysqli_query($conn, $sql)) {
            // Hapus data detail masuk dari session setelah disimpan ke dalam tabel
            unset($_SESSION['detail_keluar']);
            // Redirect kembali ke halaman form detail masuk dengan pesan sukses
            header('Location: kdua.php?success=true');
            exit();
        } else {
            // Jika terjadi kesalahan, tampilkan pesan error
            $error = "Error: " . $sql . "<br>" . mysqli_error($conn);
        }
    } else {
        // Jika tidak ada data detail masuk yang disimpan dalam session
        $error = "Tidak ada data detail masuk yang disimpan dalam session.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css">
    <link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/boxicons@latest/css/boxicons.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="formmsk.css">
</head>
<body id="body-pd">
    <header class="header" id="header">
        <div class="header_toggle"> <i class='bx bx-menu' id="header-toggle"></i> </div>
        <div class="header_img"> <img src="https://i.imgur.com/hczKIze.jpg" alt=""> </div>
    </header>
    <div class="progress">
        <div class="progress-bar bg-success" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100"></div>
    </div>

    <div class="l-navbar" id="nav-bar">
        <nav class="nav">
            <div> <a href="#" class="nav_logo"> 
            <i class='bx bx-layer nav_logo-icon'></i> 
                <span class="nav_logo-name">PT.Globalindo</span> </a>
                <div class="nav_list"> <a href="dashboard.php" class="nav_link active"><i class='bx bx-grid-alt nav_icon'></i> 
                <span class="nav_name">Dashboard</span> </a> 

                <a href="kartumasuk.php" class="nav_link"><i class='bx bx-user nav_icon'></i> 
                <span class="nav_name">Kartu Masuk</span> </a> 

                <a href="kartukeluar.php" class="nav_link"><i class='bx bx-message-square-detail nav_icon'></i> 
                <span class="nav_name">Kartu Keluar</span> </a> 

                <a href="reminder.php" class="nav_link"><i class='bx bx-home nav_icon'></i> 
                <span class="nav_name">Barang 6 bulan </span> </a> 

                <a href="inforak.php" class="nav_link"><i class='bx bx-home nav_icon'></i> 
                <span class="nav_name">Informasi Rak</span> </a>

            </div> 
            <a href="../login.php" class="nav_link"> <i class='bx bx-log-out nav_icon'></i> 
            <span class="nav_name">Keluar</span> </a>
                </div>
            </div> 
    </div>


    <!--Container Main start-->
    <div class="height-100 bg-light">
        <div class="w3-twothird">
            <div class="container">
                <div class="col-md-6 offset-md-3">
                    <h4 class="mt-5">Tambah Detail Masuk</h4>
                    <?php if ($error): ?>
                        <div class="alert alert-danger"><?php echo $error; ?></div>
                    <?php endif; ?>
                    <?php if ($success): ?>
                        <div class="alert alert-success"><?php echo $success; ?></div>
                    <?php endif; ?>
<form method="POST" action="">
<div class="mb-3">
<label for="kode_masuk" class="form-label">Kode Masuk</label>
    <?php
// Mendapatkan kode masuk terakhir
$query_last_code = "SELECT kode_keluar FROM keluar ORDER BY kode_keluar DESC LIMIT 1";
$result_last_code = mysqli_query($conn, $query_last_code);
if ($result_last_code && mysqli_num_rows($result_last_code) > 0) {
    $row_last_code = mysqli_fetch_assoc($result_last_code);
    $next_code = $row_last_code['kode_keluar'] + 0;
} else {
    // Jika tidak ada kode masuk sebelumnya, mulai dari 1
    $next_code = 0;
}

// Menampilkan input kode masuk berikutnya
echo '<input type="text" id="kode_keluar" name="kode_keluar" value="' . $next_code . '" readonly>';
            ?>   
 </div>
    <div class="mb-3">
    <label for="nama_buyer" class="form-label">Nama Buyer</label>
     <input type="text" class="form-control" id="nama_buyer" name="nama_buyer" value="<?php echo isset($last_buyer_name) ? $last_buyer_name : ''; ?>" readonly>
    </div>
    <div class="mb-3">
    <label for="nama_rak" class="form-label">Nama Rak</label>
    <input type="text" class="form-control" id="nama_rak" name="nama_rak" value="<?php echo isset($last_rak_name) ? $last_rak_name : ''; ?>" readonly>
    </div>
    <div class="mb-3">
    <label for="nama_slot" class="form-label">Nama Slot</label>
    <select class="form-control" id="nama_slot" name="nama_slot">
    <?php
    // Query untuk mendapatkan nama slot yang tersedia berdasarkan kapasitas slot
    $query_slot_tersedia = "SELECT nama_slot FROM slot WHERE kode_rak = '$kode_rak' AND kap_slot > 0";
    $result_slot_tersedia = mysqli_query($conn, $query_slot_tersedia);

    if ($result_slot_tersedia && mysqli_num_rows($result_slot_tersedia) > 0) {
 while ($row_slot_tersedia = mysqli_fetch_assoc($result_slot_tersedia)) {
    echo '<option value="' . $row_slot_tersedia['nama_slot'] . '">' . $row_slot_tersedia['nama_slot'] . '</option>';
     }
        } else {
    echo '<option value="">Tidak ada slot yang tersedia</option>';
        }
        ?>
</select>
</div>

<div class="mb-3">
    <label for="no_roll" class="form-label">Nomor Roll</label>
    <select class="form-control" id="no_roll" name="no_roll" required>
        <option value="">Pilih Nomor Roll</option>
        <?php
        // Query untuk mendapatkan kode buyer terakhir dari tabel keluar
        $query_last_buyer_code = "SELECT kode_buyer FROM keluar ORDER BY kode_keluar DESC LIMIT 1";
        $result_last_buyer_code = mysqli_query($conn, $query_last_buyer_code);

        if ($result_last_buyer_code && mysqli_num_rows($result_last_buyer_code) > 0) {
            $row_last_buyer_code = mysqli_fetch_assoc($result_last_buyer_code);
            $last_buyer_code = $row_last_buyer_code['kode_buyer'];

            // Query untuk mendapatkan nomor roll dan saldo berdasarkan kode buyer terakhir
            $query_roll = "SELECT no_roll, saldo FROM roll WHERE kode_buyer = '$last_buyer_code'";
            $result_roll = mysqli_query($conn, $query_roll);

            if ($result_roll && mysqli_num_rows($result_roll) > 0) {
                while ($row_roll = mysqli_fetch_assoc($result_roll)) {
                    // Tampilkan nomor roll dan saldo dalam opsi dropdown
                    echo '<option value="' . $row_roll['no_roll'] . '">' . $row_roll['no_roll'] . ' (Saldo: ' . $row_roll['saldo'] . ')</option>';
                }
            } else {
                echo '<option value="">Nomor Roll tidak ditemukan</option>';
            }
        } else {
            echo '<option value="">Tidak ada data keluar</option>';
        }
        ?>
    </select>
</div>

                        <div class="mb-3">
<label for="qty_keluar" class="form-label">Quantity keluar</label>
<input type="number" class="form-control" id="qty_keluar" name="qty_keluar" required></div>


                        <button type="submit" name="simpan" class="btn btn-primary">tambah</button>
                    </form>
                <div class="col-md-6 offset-md-3">
                    <div class="mb-3">
                    <a href="kartukeluar.php"><button class="btn btn-primary">Selesai</button></a>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <!--Container Main end-->

    <script src="formmsk.js"></script>
</body>
</html>
