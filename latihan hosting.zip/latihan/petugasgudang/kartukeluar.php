<html>
    <head>
        <!-- Required meta tags -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css">
<link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js'>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/boxicons@latest/css/boxicons.min.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<link rel="stylesheet" href="headertb.css">

    </head>
<body id="body-pd">
    <header class="header" id="header">
        <div class="header_toggle"> <i class='bx bx-menu' id="header-toggle"></i> </div>
        <div class="header_img"> <img src="https://th.bing.com/th/id/OIP.mHT5_JTZ1lKwFRDFsDWlVwAAAA?rs=1&pid=ImgDetMain" alt=""> </div>
 
    </header>
    <div class="l-navbar" id="nav-bar">
        <nav class="nav">
            <div> <a href="#" class="nav_logo"> 
            <i class='bx bx-layer nav_logo-icon'></i> 
                <span class="nav_logo-name">PT.Globalindo</span> </a>
                <div class="nav_list"> 
                    
                <a href="dashboard.php" class="nav_link active"><i class='bx bx-grid-alt nav_icon'></i> 
                <span class="nav_name">Dashboard</span> </a> 

                <a href="kartumasuk.php" class="nav_link"><i class='bx bx-user nav_icon'></i> 
                <span class="nav_name">Kartu Masuk</span> </a> 

                <a href="kartukeluar.php" class="nav_link"><i class='bx bx-message-square-detail nav_icon'></i> 
                <span class="nav_name">Kartu Keluar</span> </a> 

                <a href="reminder.php" class="nav_link"><i class='bx bx-home nav_icon'></i> 
                <span class="nav_name">Barang 6 bulan </span> </a> 

                <a href="inforak.php" class="nav_link"><i class='bx bx-home nav_icon'></i> 
                <span class="nav_name">Informasi Rak</span> </a>

            </div> 
            <a href="../login.php" class="nav_link"> <i class='bx bx-log-out nav_icon'></i> 
            <span class="nav_name">Keluar</span> </a>
                </div>
            </div> 
    </div>

    <!--Container Main start-->
    <div class="height-100 bg-light">
    <?php //require_once 'menu.php'; ?> 
    <div class="content">
        <h2>Data Kartu Keluar</h2>
        <div class="mb-3">
        <a href="formkeluar.php"><button type="button" class="btn btn-primary"> Tambah Kartu</button></a>
        </div>
        <table>
            <tr>
                <th> No Kartu keluar</th>
                <th> Tanggal keluar</th>
                <th> Buyer</th>
                <th> Color</th>
                <th> Artikel</th>
                <th> Supplier</th>
                <th> Unit</th>
                <th>Alokasi ORC</th>
                <th>Alokasi Style</th>
                <th>Petugas</th>
                <th>Detail</th>


            </tr>
            <?php
require_once 'config.php';

$sql = "SELECT * FROM keluar
        INNER JOIN buyer ON keluar.kode_buyer = buyer.kode_buyer
        INNER JOIN color ON keluar.kode_color = color.kode_color
        INNER JOIN artikel ON keluar.kode_artikel = artikel.kode_artikel
        INNER JOIN supplier ON keluar.kode_supplier = supplier.kode_supplier";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row["kode_keluar"] . "</td>";
        echo "<td>" . $row["tgl_keluar"] . "</td>";
        echo "<td>" . $row["nama_buyer"] . "</td>";
        echo "<td>" . $row["nama_color"] . "</td>";
        echo "<td>" . $row["nama_artikel"] . "</td>";
        echo "<td>" . $row["nama_supplier"] . "</td>";
        echo "<td>" . $row["unit"] . "</td>";
        echo "<td>" . $row["alokasi_orc"] . "</td>";
        echo "<td>" . $row["alokasi_style"] . "</td>";
        echo "<td>" . $row["petugas"] . "</td>";
        
       echo "<td><a href='detailkeluar.php?id=" . $row['kode_keluar'] . "' class='btn btn-info btn-sm'>Detail</a></td>";
    }
} else {
    echo "<tr>";
    echo "<td><div class='empty-message'>Data detailmu masih kosong, silakan isi detail.</div></td>";
    echo "</tr>";
}
?>
</div>   
</table>
        <script>
        document.addEventListener("DOMContentLoaded", function(event) {
   
   const showNavbar = (toggleId, navId, bodyId, headerId) =>{
   const toggle = document.getElementById(toggleId),
   nav = document.getElementById(navId),
   bodypd = document.getElementById(bodyId),
   headerpd = document.getElementById(headerId)
   
   // Validate that all variables exist
   if(toggle && nav && bodypd && headerpd){
   toggle.addEventListener('click', ()=>{
   // show navbar
   nav.classList.toggle('show')
   // change icon
   toggle.classList.toggle('bx-x')
   // add padding to body
   bodypd.classList.toggle('body-pd')
   // add padding to header
   headerpd.classList.toggle('body-pd')
   })
   }
   }
   
   showNavbar('header-toggle','nav-bar','body-pd','header')
   
   /*===== LINK ACTIVE =====*/
   const linkColor = document.querySelectorAll('.nav_link')
   
   function colorLink(){
   if(linkColor){
   linkColor.forEach(l=> l.classList.remove('active'))
   this.classList.add('active')
   }
   }
   linkColor.forEach(l=> l.addEventListener('click', colorLink))
   
    // Your code to run since DOM is loaded and ready
   });
   </script>
</body>
</html>
